print('****')
print('****')
print('****')
print('****')
