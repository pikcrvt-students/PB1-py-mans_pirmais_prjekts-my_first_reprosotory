print('#####')
print('$$$$$')
print('&&&&&')
