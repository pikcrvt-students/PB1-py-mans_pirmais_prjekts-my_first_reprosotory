print('   *   ')
print('  ***  ')
print(' ***** ')
print('*******')
